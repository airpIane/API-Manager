package server

import (
	"fmt"
	"log"
	"net"
	"webserver/src/config"
)

func Start() {
	l, err := net.Listen("tcp4", fmt.Sprintf("%s:%d", config.Cfg.CncServer.Host, config.Cfg.CncServer.Port))
	if err != nil {
		log.Fatal(err)
		return
	}

	log.Printf("(cnc_server) cnc Started!")

	for {
		conn, err := l.Accept()
		if err != nil {
			log.Printf("(cnc/err) %s", err)
			return
		}

		go handler(conn)
	}
}
